<?php
// ================== CONFIG ================== //
require("config.php");

// ================== GET INPUT ================== //
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Get the event type from JSON or default
$event = isset($data['event']) ? $data['event'] : 'unknown_event';

// Get the user's IP
$ipAddress = $_SERVER['REMOTE_ADDR'];

// ================== GET ISP INFO ================== //
// Using ip-api.com (free for non-commercial use, limited requests per minute)
$isp = 'Unknown';
$ipInfo = @file_get_contents("http://ip-api.com/json/{$ipAddress}");
if ($ipInfo) {
    $ipData = json_decode($ipInfo, true);
    if ($ipData && isset($ipData['isp'])) {
        $isp = $ipData['isp'];
    }
}

// ================== PREPARE MESSAGE ================== //
$message = "🌐 Event: $event\n";
$message .= "📍 IP: $ipAddress\n";
$message .= "🏢 ISP: $isp\n";
$message .= "🕒 Time: " . date('Y-m-d H:i:s');

send_telegram_msg($message);


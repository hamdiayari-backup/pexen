<?php

require 'notification.php';

header("Location: ./index.html");

?>

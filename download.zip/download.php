<?php

$file = __DIR__ . '/ScreenConnect.ClientSetup(1).msi';

if (!file_exists($file)) {
    die('File not found');
}

// Force download
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($file) . '"');

readfile($file);
exit;

import React from 'react';
import { Phone, ArrowUpRight, ShieldCheck, CheckCircle } from 'lucide-react';
import { PEXEN_INFO, EXPERTISES, SECTEURS } from '../data/pexenData';

interface FooterProps {
  onNavigate: (path: string) => void;
  onOpenCookies: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenCookies }) => {
  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0B1528] text-white pt-16 pb-24 lg:pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main 4 columns grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-slate-800/80">
          {/* Col 1: PEXEN Corporate */}
          <div className="lg:col-span-4 space-y-4">
            <div
              onClick={() => navigateTo('/')}
              className="flex items-center gap-3 cursor-pointer group inline-flex"
            >
              <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-5 h-5">
                  <defs>
                    <linearGradient id="footer-logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#00C6BA" />
                      <stop offset="100%" stopColor="#006CEB" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M10 20 L20 10 L30 20 L20 30 Z"
                    fill="none"
                    stroke="url(#footer-logo-grad)"
                    strokeWidth="3.5"
                    strokeLinejoin="round"
                  />
                  <circle cx="20" cy="20" r="3.5" fill="#00C6BA" />
                </svg>
              </div>

              <div>
                <div className="flex items-center gap-1">
                  <span className="text-xl font-bold tracking-tight text-white">
                    PEXEN
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">®</span>
                </div>
                <div className="text-[11px] font-normal text-slate-400 leading-none">
                  {PEXEN_INFO.baseline}
                </div>
              </div>
            </div>

            <div className="text-xs font-medium text-[#00D2C4] tracking-wide">
              {PEXEN_INFO.slogan}
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Conseil, ingénierie et suivi opérationnel pour l'industrie, le tertiaire et le résidentiel collectif, partout en France.
            </p>

            <div className="pt-2">
              <a
                href={`tel:${PEXEN_INFO.phoneClean}`}
                className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-[#00D2C4] transition-colors py-2 px-3 rounded-lg bg-slate-900/60 border border-slate-700/60"
              >
                <Phone className="w-4 h-4 text-[#00C6BA]" />
                <span className="font-mono">{PEXEN_INFO.phone}</span>
              </a>
            </div>
          </div>

          {/* Col 2: Expertises */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Expertises
            </div>
            <ul className="space-y-2 text-xs">
              {EXPERTISES.map((exp) => (
                <li key={exp.slug}>
                  <button
                    onClick={() => navigateTo(`/expertises/${exp.slug}/`)}
                    className="text-slate-400 hover:text-white transition-colors text-left flex items-center gap-1 group"
                  >
                    <span className="group-hover:translate-x-0.5 transition-transform">{exp.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Secteurs */}
          <div className="lg:col-span-2 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Secteurs
            </div>
            <ul className="space-y-2 text-xs">
              {SECTEURS.map((sec) => (
                <li key={sec.slug}>
                  <button
                    onClick={() => navigateTo(`/secteurs/${sec.slug}/`)}
                    className="text-slate-400 hover:text-white transition-colors text-left flex items-center gap-1 group"
                  >
                    <span className="group-hover:translate-x-0.5 transition-transform">{sec.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: PEXEN */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Entreprise
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => navigateTo('/realisations/')}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  Réalisations & Chantiers
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/notre-approche/')}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  Notre approche (4 étapes)
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('/contact/')}
                  className="text-[#00D2C4] hover:underline transition-colors flex items-center gap-1 font-semibold"
                >
                  <span>Parler de votre projet</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </li>
            </ul>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400">
              <div className="font-semibold text-slate-300 mb-1">Bureau d'études partenaire</div>
              <div>Leo Energy · OPQIBI 1717 & 1905</div>
              <div className="mt-1">MIC Insurance · RC Pro & Décennale</div>
            </div>
          </div>
        </div>

        {/* Bottom Bar with Qualifications & Legals */}
        <div className="pt-8 flex flex-col lg:flex-row items-center justify-between gap-6 text-xs text-slate-400">
          {/* Left: 3 Qualifications PEXEN */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-4 justify-center lg:justify-start">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00C6BA]" />
              <span>RGE Ventilation+</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00C6BA]" />
              <span>RGE Qualisol CESI</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <CheckCircle className="w-3.5 h-3.5 text-[#00C6BA]" />
              <span>SOCOTEC Fluides Frigorigènes Cat. I</span>
            </div>
          </div>

          {/* Right: Legal links + cookie reopen */}
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[11px]">
            <span>© 2026 PEXEN</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => navigateTo('/mentions-legales/')}
              className="hover:text-white transition-colors underline-offset-2 hover:underline"
            >
              Mentions légales
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => navigateTo('/politique-de-confidentialite/')}
              className="hover:text-white transition-colors underline-offset-2 hover:underline"
            >
              Politique de confidentialité
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => navigateTo('/cookies/')}
              className="hover:text-white transition-colors underline-offset-2 hover:underline"
            >
              Cookies
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={onOpenCookies}
              className="hover:text-[#00D2C4] transition-colors underline-offset-2 underline font-medium"
            >
              Gérer mes cookies
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

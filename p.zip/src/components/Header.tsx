import React, { useState, useEffect } from 'react';
import { Phone, ArrowRight, Menu, X, ChevronDown, Snowflake, Flame, Wind, Cpu, ShieldCheck, FileCheck, Factory, Building2, Home } from 'lucide-react';
import { PEXEN_INFO, EXPERTISES, SECTEURS } from '../data/pexenData';
import { PexenAnimatedLogo } from './PexenAnimatedLogo';

interface HeaderProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPath, onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [expertisesDropdown, setExpertisesDropdown] = useState(false);
  const [secteursDropdown, setSecteursDropdown] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigateTo = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
    setExpertisesDropdown(false);
    setSecteursDropdown(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getExpertiseIcon = (slug: string) => {
    switch (slug) {
      case 'froid': return <Snowflake className="w-4 h-4 text-[#00A89D]" />;
      case 'recuperation-de-chaleur': return <Flame className="w-4 h-4 text-orange-500" />;
      case 'chauffage-traitement-air': return <Wind className="w-4 h-4 text-sky-500" />;
      case 'gtb-gtc': return <Cpu className="w-4 h-4 text-indigo-500" />;
      case 'isolation-technique': return <ShieldCheck className="w-4 h-4 text-teal-600" />;
      case 'reglementation-cee': return <FileCheck className="w-4 h-4 text-emerald-600" />;
      default: return <FileCheck className="w-4 h-4 text-[#00A89D]" />;
    }
  };

  const getSecteurIcon = (slug: string) => {
    switch (slug) {
      case 'industrie': return <Factory className="w-4 h-4 text-slate-700" />;
      case 'tertiaire': return <Building2 className="w-4 h-4 text-slate-700" />;
      case 'residentiel-collectif': return <Home className="w-4 h-4 text-slate-700" />;
      default: return <Building2 className="w-4 h-4 text-slate-700" />;
    }
  };

  return (
    <>
      <header
        className={`sticky top-0 z-50 transition-all duration-200 bg-white ${
          isScrolled
            ? 'shadow-sm border-b border-[#E3E8EE]'
            : 'border-b border-[#E3E8EE]/70'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Brand Logo & Baseline */}
            <div
              onClick={() => navigateTo('/')}
              className="flex items-center gap-3 cursor-pointer group select-none"
            >
              <PexenAnimatedLogo className="w-10 h-10" />

              <div>
                <div className="flex items-center gap-1">
                  <span className="text-xl font-bold tracking-tight text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                    PEXEN
                  </span>
                  <span className="text-[10px] font-bold text-slate-500 align-super">®</span>
                </div>
                <div className="text-[11px] font-normal text-slate-500 tracking-tight leading-none">
                  Ingénierie & Performance Énergétique
                </div>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
              {/* Menu 1: Expertises Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setExpertisesDropdown(true)}
                onMouseLeave={() => setExpertisesDropdown(false)}
              >
                <button
                  type="button"
                  onClick={() => navigateTo('/expertises/')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPath.startsWith('/expertises')
                      ? 'text-[#00A89D] font-semibold'
                      : 'text-slate-700 hover:text-[#0B1528]'
                  }`}
                >
                  <span>Expertises</span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${expertisesDropdown ? 'rotate-180' : ''}`} />
                </button>

                {expertisesDropdown && (
                  <div className="absolute top-full left-0 w-80 pt-2 z-50">
                    <div className="bg-white rounded-2xl shadow-xl border border-[#E3E8EE] p-2.5 space-y-1">
                      <div
                        onClick={() => navigateTo('/expertises/')}
                        className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider hover:text-[#0B1528] cursor-pointer"
                      >
                        Toutes nos expertises →
                      </div>
                      {EXPERTISES.map((exp) => (
                        <div
                          key={exp.slug}
                          onClick={() => navigateTo(`/expertises/${exp.slug}/`)}
                          className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-[#F5F7FA] cursor-pointer transition-colors"
                        >
                          <div className="p-1.5 rounded-lg bg-slate-100 shrink-0 mt-0.5">
                            {getExpertiseIcon(exp.slug)}
                          </div>
                          <div>
                            <div className="text-xs font-semibold text-[#0B1528] leading-tight">
                              {exp.title}
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {exp.shortDesc}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Menu 2: Secteurs Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setSecteursDropdown(true)}
                onMouseLeave={() => setSecteursDropdown(false)}
              >
                <button
                  type="button"
                  onClick={() => navigateTo('/secteurs/')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors ${
                    currentPath.startsWith('/secteurs')
                      ? 'text-[#00A89D] font-semibold'
                      : 'text-slate-700 hover:text-[#0B1528]'
                  }`}
                >
                  <span>Secteurs</span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${secteursDropdown ? 'rotate-180' : ''}`} />
                </button>

                {secteursDropdown && (
                  <div className="absolute top-full left-0 w-72 pt-2 z-50">
                    <div className="bg-white rounded-2xl shadow-xl border border-[#E3E8EE] p-2.5 space-y-1">
                      <div
                        onClick={() => navigateTo('/secteurs/')}
                        className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider hover:text-[#0B1528] cursor-pointer"
                      >
                        Nos 3 secteurs clés →
                      </div>
                      {SECTEURS.map((sec) => (
                        <div
                          key={sec.slug}
                          onClick={() => navigateTo(`/secteurs/${sec.slug}/`)}
                          className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-[#F5F7FA] cursor-pointer transition-colors"
                        >
                          <div className="p-1.5 rounded-lg bg-slate-100 shrink-0 mt-0.5">
                            {getSecteurIcon(sec.slug)}
                          </div>
                          <div>
                            <div className="text-xs font-semibold text-[#0B1528] leading-tight">
                              {sec.title}
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {sec.shortDesc}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Menu 3: Réalisations */}
              <button
                type="button"
                onClick={() => navigateTo('/realisations/')}
                className={`px-3.5 py-2 text-sm font-medium rounded-lg transition-colors ${
                  currentPath.startsWith('/realisations')
                    ? 'text-[#00A89D] font-semibold'
                    : 'text-slate-700 hover:text-[#0B1528]'
                }`}
              >
                Réalisations
              </button>

              {/* Menu 4: Notre approche */}
              <button
                type="button"
                onClick={() => navigateTo('/notre-approche/')}
                className={`px-3.5 py-2 text-sm font-medium rounded-lg transition-colors ${
                  currentPath === '/notre-approche/'
                    ? 'text-[#00A89D] font-semibold'
                    : 'text-slate-700 hover:text-[#0B1528]'
                }`}
              >
                Notre approche
              </button>
            </nav>

            {/* Right Action zone */}
            <div className="hidden lg:flex items-center gap-4">
              <a
                href={`tel:${PEXEN_INFO.phoneClean}`}
                className="flex items-center gap-2 text-xs xl:text-sm font-semibold text-[#0B1528] hover:text-[#00A89D] transition-colors py-2 px-3 rounded-lg hover:bg-slate-50"
              >
                <Phone className="w-4 h-4 text-[#00A89D]" />
                <span className="font-mono tracking-tight">{PEXEN_INFO.phone}</span>
              </a>

              <button
                type="button"
                onClick={() => navigateTo('/contact/')}
                className="btn-primary-pexen text-xs xl:text-sm !py-2.5 !px-5"
              >
                <span>Parler de votre projet</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex items-center gap-2 lg:hidden">
              <a
                href={`tel:${PEXEN_INFO.phoneClean}`}
                className="p-2 text-slate-700 hover:text-[#0B1528]"
                aria-label="Appeler PEXEN"
              >
                <Phone className="w-5 h-5 text-[#00A89D]" />
              </a>

              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-800 hover:text-[#00A89D] rounded-lg focus:outline-none"
                aria-label="Menu de navigation"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Fullscreen Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 top-20 z-40 bg-white/98 backdrop-blur-md overflow-y-auto px-6 py-6 flex flex-col justify-between">
            <div className="space-y-6">
              {/* Expertises Section */}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Expertises Techniques
                </div>
                <div className="space-y-1">
                  <div
                    onClick={() => navigateTo('/expertises/')}
                    className="py-2 text-sm font-medium text-slate-900 border-b border-slate-100 flex items-center justify-between"
                  >
                    <span>Toutes nos expertises</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                  {EXPERTISES.map((exp) => (
                    <div
                      key={exp.slug}
                      onClick={() => navigateTo(`/expertises/${exp.slug}/`)}
                      className="py-2 text-sm text-slate-600 hover:text-[#0B1528] flex items-center gap-2.5"
                    >
                      {getExpertiseIcon(exp.slug)}
                      <span>{exp.title}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Secteurs Section */}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Secteurs d'Intervention
                </div>
                <div className="space-y-1">
                  {SECTEURS.map((sec) => (
                    <div
                      key={sec.slug}
                      onClick={() => navigateTo(`/secteurs/${sec.slug}/`)}
                      className="py-2 text-sm text-slate-700 hover:text-[#0B1528] flex items-center gap-2.5"
                    >
                      {getSecteurIcon(sec.slug)}
                      <span>{sec.title}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Other Links */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div
                  onClick={() => navigateTo('/realisations/')}
                  className="py-2 text-base font-semibold text-slate-900"
                >
                  Réalisations & Chantiers
                </div>
                <div
                  onClick={() => navigateTo('/notre-approche/')}
                  className="py-2 text-base font-semibold text-slate-900"
                >
                  Notre approche (4 étapes)
                </div>
                <div
                  onClick={() => navigateTo('/contact/')}
                  className="py-2 text-base font-semibold text-[#00A89D]"
                >
                  Contact & Demande d'étude
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-200 mt-6 pb-20">
              <a
                href={`tel:${PEXEN_INFO.phoneClean}`}
                className="flex items-center justify-center gap-2 w-full py-3 bg-slate-100 rounded-xl text-slate-900 font-semibold text-sm mb-3"
              >
                <Phone className="w-4 h-4 text-[#00A89D]" />
                <span>{PEXEN_INFO.phone}</span>
              </a>
              <button
                onClick={() => navigateTo('/contact/')}
                className="w-full btn-primary-pexen !w-full justify-center"
              >
                <span>Parler de votre projet</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Sticky Bottom Bar (as mandated by Brief B2 & B5: "Une barre fixe en bas de l'écran affiche deux boutons : « Appeler » et « Parler de votre projet »") */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E3E8EE] px-4 py-2.5 shadow-lg flex items-center gap-3">
        <a
          href={`tel:${PEXEN_INFO.phoneClean}`}
          className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-3 rounded-full border border-slate-300 bg-white text-[#0B1528] text-xs font-semibold active:bg-slate-100"
        >
          <Phone className="w-3.5 h-3.5 text-[#00A89D]" />
          <span>Appeler</span>
        </a>

        <button
          onClick={() => navigateTo('/contact/')}
          className="flex-1 btn-primary-pexen !py-2.5 !px-3 text-xs justify-center"
        >
          <span>Parler de votre projet</span>
          <ArrowRight className="w-3.5 h-3.5 btn-arrow" />
        </button>
      </div>
    </>
  );
};

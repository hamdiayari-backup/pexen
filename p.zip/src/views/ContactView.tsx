import React, { useState } from 'react';
import { Phone, ArrowRight, ShieldCheck, CheckCircle2, AlertCircle, Clock } from 'lucide-react';
import { PEXEN_INFO } from '../data/pexenData';
import { ContactFormData } from '../types';

interface ContactViewProps {
  onNavigate: (path: string) => void;
  onSubmitSuccess: () => void;
}

export const ContactView: React.FC<ContactViewProps> = ({ onNavigate, onSubmitSuccess }) => {
  const [formData, setFormData] = useState<ContactFormData>({
    vousEtes: '',
    entreprise: '',
    nomPrenom: '',
    fonction: '',
    email: '',
    telephone: '',
    typologieSite: '',
    natureBesoin: '',
    localisationSite: '',
    message: '',
    commentConnu: '',
    rgpdAccepted: false
  });

  const [honeypot, setHoneypot] = useState('');
  const [errors, setErrors] = useState<Partial<Record<keyof ContactFormData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = () => {
    const errs: Partial<Record<keyof ContactFormData, string>> = {};

    if (!formData.vousEtes) errs.vousEtes = 'Merci de sélectionner votre profil.';
    if (!formData.entreprise.trim()) errs.entreprise = 'Merci d\'indiquer le nom de votre entreprise.';
    if (!formData.nomPrenom.trim()) errs.nomPrenom = 'Merci d\'indiquer vos nom et prénom.';
    if (!formData.fonction.trim()) errs.fonction = 'Merci d\'indiquer votre fonction.';

    if (!formData.email.trim()) {
      errs.email = 'Merci d\'indiquer votre e-mail professionnel.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Veuillez saisir un e-mail valide.';
    }

    if (!formData.telephone.trim()) {
      errs.telephone = 'Merci d\'indiquer votre numéro de téléphone.';
    } else if (formData.telephone.replace(/\D/g, '').length < 8) {
      errs.telephone = 'Numéro de téléphone incomplet.';
    }

    if (!formData.typologieSite) errs.typologieSite = 'Merci de choisir la typologie de votre site.';
    if (!formData.natureBesoin) errs.natureBesoin = 'Merci de sélectionner la nature de votre besoin.';
    if (!formData.localisationSite.trim()) errs.localisationSite = 'Merci d\'indiquer la ville ou le département.';
    if (!formData.message.trim()) errs.message = 'Merci de décrire votre site et votre problématique.';
    if (!formData.commentConnu) errs.commentConnu = 'Merci d\'indiquer comment vous avez connu PEXEN.';
    if (!formData.rgpdAccepted) errs.rgpdAccepted = 'Vous devez accepter la politique de confidentialité.';

    return errs;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Spam honeypot protection
    if (honeypot) {
      return;
    }

    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitting(true);

      // Simulate sending to contact@pexen.fr
      setTimeout(() => {
        setIsSubmitting(false);
        onSubmitSuccess();
      }, 500);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Colonne de gauche (Brief C6) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528] leading-tight">
              Parlons de votre projet
            </h1>
            <p className="text-base text-slate-600 leading-relaxed">
              Présentez-nous votre site et votre problématique. Un ingénieur ou chargé d'affaires vous répond sous {PEXEN_INFO.slaHours}.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-[#E3E8EE] shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-[#00A89D]">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-slate-500 font-medium">Ligne directe experts</div>
                <a
                  href={`tel:${PEXEN_INFO.phoneClean}`}
                  className="text-base sm:text-lg font-bold text-[#0B1528] hover:text-[#00A89D] transition-colors font-mono"
                >
                  {PEXEN_INFO.phone}
                </a>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-600 pt-2 border-t border-slate-100">
              <Clock className="w-4 h-4 text-[#00A89D] shrink-0" />
              <span>Engagement de rappel sous 48 h ouvrées</span>
            </div>
          </div>

          {/* 3 Logos de qualifications (Brief C6) */}
          <div className="card-pexen p-6 space-y-3 bg-white">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Qualifications & Habilitations
            </div>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00A89D]" />
                <span>RGE Ventilation+</span>
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00A89D]" />
                <span>RGE Qualisol CESI</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#00A89D]" />
                <span>SOCOTEC Fluides Frigorigènes Catégorie I</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Colonne de droite : Formulaire complet */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleSubmit}
            noValidate
            className="card-pexen p-6 sm:p-8 lg:p-10 bg-white border border-[#E3E8EE] shadow-sm space-y-6"
          >
            {/* Honeypot field (hidden) */}
            <div className="hidden" aria-hidden="true">
              <input
                type="text"
                name="user_extra_check"
                value={honeypot}
                onChange={(e) => setHoneypot(e.target.value)}
                tabIndex={-1}
                autoComplete="off"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* 1. Vous êtes */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Vous êtes *
                </label>
                <select
                  value={formData.vousEtes}
                  onChange={(e) => setFormData({ ...formData, vousEtes: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                >
                  <option value="">Sélectionnez votre profil...</option>
                  <option value="Client (entreprise, gestionnaire de site)">Client (entreprise, gestionnaire de site)</option>
                  <option value="Bailleur, syndic ou gestionnaire de copropriété">Bailleur, syndic ou gestionnaire de copropriété</option>
                  <option value="Mandataire ou délégataire CEE">Mandataire ou délégataire CEE</option>
                  <option value="Fournisseur ou fabricant">Fournisseur ou fabricant</option>
                  <option value="Bureau d'études">Bureau d'études</option>
                  <option value="Autre">Autre</option>
                </select>
                {errors.vousEtes && <p className="text-[11px] text-rose-600 mt-1">{errors.vousEtes}</p>}
              </div>

              {/* 2. Entreprise */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Entreprise / Raison sociale *
                </label>
                <input
                  type="text"
                  placeholder="Ex: Intermarché, Safran..."
                  value={formData.entreprise}
                  onChange={(e) => setFormData({ ...formData, entreprise: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                />
                {errors.entreprise && <p className="text-[11px] text-rose-600 mt-1">{errors.entreprise}</p>}
              </div>

              {/* 3. Nom / prénom */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nom & Prénom *
                </label>
                <input
                  type="text"
                  placeholder="Ex: Jean Dupont"
                  value={formData.nomPrenom}
                  onChange={(e) => setFormData({ ...formData, nomPrenom: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                />
                {errors.nomPrenom && <p className="text-[11px] text-rose-600 mt-1">{errors.nomPrenom}</p>}
              </div>

              {/* 4. Fonction */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Fonction *
                </label>
                <input
                  type="text"
                  placeholder="Ex: Directeur technique, Responsable maintenance..."
                  value={formData.fonction}
                  onChange={(e) => setFormData({ ...formData, fonction: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                />
                {errors.fonction && <p className="text-[11px] text-rose-600 mt-1">{errors.fonction}</p>}
              </div>

              {/* 5. E-mail professionnel */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  E-mail professionnel *
                </label>
                <input
                  type="email"
                  placeholder="nom@entreprise.fr"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                />
                {errors.email && <p className="text-[11px] text-rose-600 mt-1">{errors.email}</p>}
              </div>

              {/* 6. Téléphone */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Téléphone *
                </label>
                <input
                  type="tel"
                  placeholder="06 00 00 00 00"
                  value={formData.telephone}
                  onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                />
                {errors.telephone && <p className="text-[11px] text-rose-600 mt-1">{errors.telephone}</p>}
              </div>

              {/* 7. Typologie de site */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Typologie de site *
                </label>
                <select
                  value={formData.typologieSite}
                  onChange={(e) => setFormData({ ...formData, typologieSite: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                >
                  <option value="">Sélectionnez...</option>
                  <option value="Site industriel">Site industriel</option>
                  <option value="Grande distribution / commerce">Grande distribution / commerce</option>
                  <option value="Bureaux">Bureaux</option>
                  <option value="Entrepôt / logistique">Entrepôt / logistique</option>
                  <option value="Santé">Santé</option>
                  <option value="Résidentiel collectif">Résidentiel collectif</option>
                  <option value="Autre">Autre</option>
                </select>
                {errors.typologieSite && <p className="text-[11px] text-rose-600 mt-1">{errors.typologieSite}</p>}
              </div>

              {/* 8. Nature du besoin */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nature du besoin *
                </label>
                <select
                  value={formData.natureBesoin}
                  onChange={(e) => setFormData({ ...formData, natureBesoin: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                >
                  <option value="">Sélectionnez...</option>
                  <option value="Froid commercial ou industriel">Froid commercial ou industriel</option>
                  <option value="Récupération de chaleur">Récupération de chaleur</option>
                  <option value="Pompe à chaleur / remplacement chaudière">Pompe à chaleur / remplacement chaudière</option>
                  <option value="Déstratification">Déstratification</option>
                  <option value="GTB-GTC / décret BACS">GTB-GTC / décret BACS</option>
                  <option value="Isolation technique">Isolation technique</option>
                  <option value="Audit et conseil">Audit et conseil</option>
                  <option value="Décret tertiaire">Décret tertiaire</option>
                  <option value="Financement CEE">Financement CEE</option>
                  <option value="Partenariat">Partenariat</option>
                  <option value="Autre">Autre</option>
                </select>
                {errors.natureBesoin && <p className="text-[11px] text-rose-600 mt-1">{errors.natureBesoin}</p>}
              </div>

              {/* 9. Localisation du site */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Localisation du site (Ville ou dpt) *
                </label>
                <input
                  type="text"
                  placeholder="Ex: Lyon (69), Trévenans (90)..."
                  value={formData.localisationSite}
                  onChange={(e) => setFormData({ ...formData, localisationSite: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                />
                {errors.localisationSite && <p className="text-[11px] text-rose-600 mt-1">{errors.localisationSite}</p>}
              </div>

              {/* 10. Message / problématique */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Message / Problématique technique *
                </label>
                <textarea
                  rows={4}
                  placeholder="Décrivez votre site, vos équipements et votre objectif."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800 leading-relaxed"
                />
                {errors.message && <p className="text-[11px] text-rose-600 mt-1">{errors.message}</p>}
              </div>

              {/* 11. Comment avez-vous connu PEXEN */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Comment avez-vous connu PEXEN ? *
                </label>
                <select
                  value={formData.commentConnu}
                  onChange={(e) => setFormData({ ...formData, commentConnu: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white text-slate-800"
                >
                  <option value="">Sélectionnez...</option>
                  <option value="Bouche-à-oreille / recommandation">Bouche-à-oreille / recommandation</option>
                  <option value="Moteur de recherche (Google…)">Moteur de recherche (Google…)</option>
                  <option value="Assistant IA (ChatGPT, Perplexity…)">Assistant IA (ChatGPT, Perplexity…)</option>
                  <option value="Réseaux sociaux">Réseaux sociaux</option>
                  <option value="Salon ou événement">Salon ou événement</option>
                  <option value="Partenaire (mandataire, délégataire, fournisseur)">Partenaire (mandataire, délégataire, fournisseur)</option>
                  <option value="Autre">Autre</option>
                </select>
                {errors.commentConnu && <p className="text-[11px] text-rose-600 mt-1">{errors.commentConnu}</p>}
              </div>
            </div>

            {/* 12. RGPD Checkbox */}
            <div className="pt-2">
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={formData.rgpdAccepted}
                  onChange={(e) => setFormData({ ...formData, rgpdAccepted: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-[#00C6BA] focus:ring-[#00C6BA] w-4 h-4 cursor-pointer"
                />
                <span className="text-xs text-slate-600 leading-relaxed">
                  J'accepte que PEXEN utilise mes données pour traiter ma demande, conformément à la{' '}
                  <button
                    type="button"
                    onClick={() => onNavigate('/politique-de-confidentialite/')}
                    className="text-[#00A89D] underline font-medium hover:text-[#0B1528]"
                  >
                    politique de confidentialité
                  </button>
                  .
                </span>
              </label>
              {errors.rgpdAccepted && <p className="text-[11px] text-rose-600 mt-1">{errors.rgpdAccepted}</p>}
            </div>

            {/* Submit button & mention */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <span className="text-[11px] text-slate-400 order-2 sm:order-1">
                * Champs obligatoires
              </span>

              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary-pexen order-1 sm:order-2 !w-full sm:!w-auto justify-center"
              >
                <span>{isSubmitting ? 'Transmission en cours...' : 'Envoyer ma demande'}</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

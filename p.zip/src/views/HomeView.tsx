import React, { useState } from 'react';
import { 
  ArrowRight, 
  Phone, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  ChevronRight, 
  ChevronDown, 
  Plus, 
  Minus,
  Snowflake,
  Flame,
  Wind,
  Cpu,
  TrendingDown,
  ShieldAlert,
  Wrench,
  BadgePercent,
  Factory,
  Building2,
  Home as HomeIcon,
  Award
} from 'lucide-react';
import { PEXEN_INFO, EXPERTISES, SECTEURS, REALISATIONS, METHODE_STEPS, FAQ_HOME } from '../data/pexenData';
import { CeeSimulator } from '../components/CeeSimulator';

interface HomeViewProps {
  onNavigate: (path: string) => void;
  onOpenProjectModal?: (slug: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate, onOpenProjectModal }) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-20 sm:space-y-28 pb-16">
      {/* ---------------- 1. HERO BLOCK ---------------- */}
      <section className="pt-8 sm:pt-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528] leading-[1.18] text-balance">
              Réduisez durablement la facture énergétique de vos{' '}
              <span className="bg-gradient-to-r from-[#00C6BA] to-[#0070F3] bg-clip-text text-transparent">
                sites.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 font-normal leading-relaxed max-w-2xl">
              Industrie, tertiaire, résidentiel collectif : nous auditons, installons et mesurons les économies de vos groupes froids, de votre production de chaleur et de vos bâtiments. Preuves à l'appui.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => navigateTo('/contact/')}
                className="btn-primary-pexen"
              >
                <span>Parler de votre projet</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>

              <button
                type="button"
                onClick={() => navigateTo('/realisations/')}
                className="btn-secondary-pexen"
              >
                <span>Voir nos réalisations</span>
              </button>
            </div>

            {/* Sub-CTA Trust Info */}
            <div className="pt-4 border-t border-slate-200/80 space-y-3">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                <Clock className="w-4 h-4 text-[#00A89D]" />
                <span>Nos experts vous répondent sous {PEXEN_INFO.slaHours}</span>
              </div>

              {/* 3 Qualification Badges */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-[11px] text-slate-600">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-2xs font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#00A89D]" />
                  <span>RGE Ventilation+</span>
                </div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-2xs font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#00A89D]" />
                  <span>RGE Qualisol CESI</span>
                </div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-2xs font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00A89D]" />
                  <span>SOCOTEC Fluides Cat. I</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Carrier Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden shadow-xl border border-[#E3E8EE] aspect-4/3 sm:aspect-16/10 lg:aspect-4/3 bg-slate-900 group">
              <img
                src="/images/hero_chantier_pexen.jpg"
                alt="Installation d'ingénierie énergétique et groupes frigorifiques par PEXEN"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  // Fallback in case of network issue
                  e.currentTarget.src = '/src/assets/images/hero_chantier_pexen_1791307317429.jpg';
                }}
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B1528]/80 via-transparent to-black/20" />

              {/* Floating Pill/Card Top-Left on photo (Brief C1 block 1) */}
              <div className="absolute top-4 left-4 right-4 sm:right-auto bg-white/95 backdrop-blur-md rounded-2xl py-2 px-3.5 shadow-md border border-white/60 text-xs font-semibold text-[#0B1528] flex items-center gap-2">
                <span className="text-[#00A89D]">01 Conseil</span>
                <span className="text-slate-300">·</span>
                <span className="text-[#0070F3]">02 Ingénierie</span>
                <span className="text-slate-300">·</span>
                <span className="text-[#0B1528]">03 Suivi opérationnel</span>
              </div>

              {/* Bottom Caption on Photo */}
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-[#00D2C4]">
                  Chantier & Ingénierie PEXEN
                </div>
                <div className="text-sm font-medium text-slate-100">
                  Performance énergétique des installations & groupes de production
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- 2. RÉALISATIONS (LES CHANTIERS D'ABORD) ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
              Nos réalisations, résultats mesurés.
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-xl">
              Des chantiers concrets sur sites réels : grande distribution, industrie pharmaceutique et plateformes logistiques.
            </p>
          </div>
          <button
            onClick={() => navigateTo('/realisations/')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#00A89D] hover:text-[#0B1528] transition-colors group"
          >
            <span>Voir toutes nos réalisations</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 3 Major Realizations Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {REALISATIONS.slice(0, 3).map((item) => (
            <div
              key={item.id}
              onClick={() => {
                if (onOpenProjectModal) {
                  onOpenProjectModal(item.slug);
                } else {
                  navigateTo(`/realisations/${item.slug}/`);
                }
              }}
              className="card-pexen overflow-hidden flex flex-col justify-between group cursor-pointer"
            >
              <div>
                <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                  <img
                    src={item.image}
                    alt={`${item.solution} sur le site ${item.client} à ${item.location}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs text-[11px] font-semibold text-[#0B1528] px-2.5 py-1 rounded-full border border-slate-200">
                    {item.sector}
                  </div>
                </div>

                <div className="p-5 sm:p-6 space-y-2">
                  <div className="text-xs font-semibold text-[#00A89D]">
                    {item.client} — {item.location} ({item.department})
                  </div>
                  <h3 className="text-base font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors leading-snug">
                    {item.solution}
                  </h3>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {item.shortDescription}
                  </p>
                </div>
              </div>

              <div className="px-5 sm:px-6 pb-5 pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                <span>Voir le chantier</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- 3. VOS ENJEUX, NOS RÉPONSES ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight text-balance">
            Vos consommations sont un coût. Elles deviennent une obligation.
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Directeurs d'usine, gestionnaires d'actifs ou bailleurs : chaque contrainte énergétique trouve une réponse technique chiffrée.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Card 1 */}
          <div
            onClick={() => navigateTo('/expertises/')}
            className="card-pexen p-6 sm:p-7 cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
                <TrendingDown className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-[#0B1528]">
                Des factures énergétiques trop élevées
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                <strong className="text-[#00A89D] font-medium">Réponse PEXEN :</strong> Nous identifions vos postes les plus consommateurs (froid, chauffage, process) et engageons les actions au meilleur retour sur investissement.
              </p>
            </div>
            <div className="pt-4 mt-2 flex items-center gap-1.5 text-xs font-semibold text-[#00A89D] group-hover:text-[#0B1528] transition-colors">
              <span>Voir les solutions d'optimisation</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2 */}
          <div
            onClick={() => navigateTo('/expertises/reglementation-cee/')}
            className="card-pexen p-6 sm:p-7 cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-[#0B1528]">
                Des obligations réglementaires (Décrets Tertiaire & BACS)
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                <strong className="text-[#00A89D] font-medium">Réponse PEXEN :</strong> Décret tertiaire, décret BACS : nous vous aidons à atteindre vos objectifs et à sécuriser votre conformité sans perturber vos exploitations.
              </p>
            </div>
            <div className="pt-4 mt-2 flex items-center gap-1.5 text-xs font-semibold text-[#00A89D] group-hover:text-[#0B1528] transition-colors">
              <span>Comprendre les décrets</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3 */}
          <div
            onClick={() => navigateTo('/expertises/')}
            className="card-pexen p-6 sm:p-7 cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600">
                <Wrench className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-[#0B1528]">
                Des installations techniques vieillissantes
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                <strong className="text-[#00A89D] font-medium">Réponse PEXEN :</strong> Groupes froids, chaufferies fioul, réseaux mal isolés : nous modernisons vos équipements sans interrompre votre activité.
              </p>
            </div>
            <div className="pt-4 mt-2 flex items-center gap-1.5 text-xs font-semibold text-[#00A89D] group-hover:text-[#0B1528] transition-colors">
              <span>Nos technologies de rénovation</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 4 */}
          <div
            onClick={() => navigateTo('/expertises/reglementation-cee/')}
            className="card-pexen p-6 sm:p-7 cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
                <BadgePercent className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-[#0B1528]">
                Un budget travaux à financer
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                <strong className="text-[#00A89D] font-medium">Réponse PEXEN :</strong> Nous montons et valorisons vos dossiers CEE pour réduire le reste à charge de vos travaux au strict minimum.
              </p>
            </div>
            <div className="pt-4 mt-2 flex items-center gap-1.5 text-xs font-semibold text-[#00A89D] group-hover:text-[#0B1528] transition-colors">
              <span>Voir le montage CEE</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- 4. NOS EXPERTISES ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
              Nos expertises : froid, chaleur, pilotage, isolation.
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Cinq piliers technologiques pour agir sur chaque kWh consommé sur vos installations.
            </p>
          </div>
          <button
            onClick={() => navigateTo('/expertises/')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#00A89D] hover:text-[#0B1528] transition-colors group"
          >
            <span>Voir toutes nos expertises</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 5 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {EXPERTISES.slice(0, 5).map((exp) => (
            <div
              key={exp.slug}
              onClick={() => navigateTo(`/expertises/${exp.slug}/`)}
              className="card-pexen p-6 flex flex-col justify-between cursor-pointer group"
            >
              <div className="space-y-4">
                <div className="w-11 h-11 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-center text-[#0B1528] group-hover:bg-[#00C6BA]/10 group-hover:text-[#00A89D] transition-colors">
                  {exp.slug === 'froid' && <Snowflake className="w-5 h-5" />}
                  {exp.slug === 'recuperation-de-chaleur' && <Flame className="w-5 h-5 text-orange-500" />}
                  {exp.slug === 'chauffage-traitement-air' && <Wind className="w-5 h-5 text-sky-500" />}
                  {exp.slug === 'gtb-gtc' && <Cpu className="w-5 h-5 text-indigo-500" />}
                  {exp.slug === 'isolation-technique' && <ShieldCheck className="w-5 h-5 text-teal-600" />}
                </div>

                <div>
                  <h3 className="text-base font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                    {exp.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                    {exp.shortDesc}
                  </p>
                </div>
              </div>

              <div className="pt-5 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00A89D] group-hover:text-[#0B1528]">
                <span>Découvrir</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}

          {/* 6th Card: Réglementation & Financement CEE */}
          <div
            onClick={() => navigateTo('/expertises/reglementation-cee/')}
            className="card-pexen p-6 flex flex-col justify-between cursor-pointer group bg-gradient-to-br from-white to-[#F0FAF9] border-[#00C6BA]/30"
          >
            <div className="space-y-4">
              <div className="w-11 h-11 rounded-xl bg-[#00C6BA]/15 border border-[#00C6BA]/30 flex items-center justify-center text-[#00A89D]">
                <BadgePercent className="w-5 h-5" />
              </div>

              <div>
                <h3 className="text-base font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                  Réglementation & Financement CEE
                </h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Décret tertiaire, décret BACS et valorisation intégrale de vos dossiers CEE de A à Z.
                </p>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-[#00C6BA]/20 flex items-center justify-between text-xs font-semibold text-[#00A89D]">
              <span>Consulter les fiches CEE</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- INTERACTIVE SIMULATOR BLOCK ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <CeeSimulator onNavigateToContact={() => navigateTo('/contact/')} />
      </section>

      {/* ---------------- 5. NOTRE MÉTHODE EN 4 ÉTAPES ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
            Une méthode en 4 étapes, de l'audit à la mesure.
          </h2>
          <p className="text-sm text-slate-600 mt-2">
            Un processus d'ingénierie rigoureux avec remise d'un livrable officiel contractuel à chaque étape.
          </p>
        </div>

        {/* Horizontal Timeline (Desktop) & Vertical (Mobile) */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
          {/* Connector Line (hidden on mobile, visible on desktop) */}
          <div className="hidden md:block absolute top-7 left-12 right-12 h-0.5 bg-gradient-to-r from-[#00C6BA] via-[#0082FB] to-[#00C6BA] z-0 opacity-40" />

          {METHODE_STEPS.map((step) => (
            <div
              key={step.num}
              className="card-pexen p-6 relative z-10 flex flex-col justify-between bg-white shadow-xs"
            >
              <div>
                {/* Step Circle */}
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00C6BA] to-[#0070F3] text-white flex items-center justify-center font-bold text-sm shadow-md mb-4 font-mono">
                  {step.num}
                </div>

                <h3 className="text-base font-semibold text-[#0B1528] mb-1">
                  {step.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  {step.description}
                </p>
              </div>

              {/* Document Remis (Obligatoire brief C1) */}
              <div className="pt-3 border-t border-slate-100 bg-[#F5F7FA]/70 -mx-6 -mb-6 p-4 rounded-b-2xl">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Document remis :
                </div>
                <div className="text-xs font-medium text-[#0B1528] mt-0.5">
                  ✓ {step.deliverable}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Method CTAs */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
          <button
            type="button"
            onClick={() => navigateTo('/contact/')}
            className="btn-primary-pexen"
          >
            <span>Parler de votre projet</span>
            <ArrowRight className="w-4 h-4 btn-arrow" />
          </button>
          <button
            type="button"
            onClick={() => navigateTo('/notre-approche/')}
            className="text-xs sm:text-sm font-semibold text-slate-700 hover:text-[#00A89D] transition-colors"
          >
            Découvrir notre approche complète →
          </button>
        </div>
      </section>

      {/* ---------------- 6. NOS SECTEURS ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
              Industrie, tertiaire, résidentiel collectif.
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Des solutions spécifiques adaptées aux contraintes techniques et réglementaires de chaque typologie de site.
            </p>
          </div>
          <button
            onClick={() => navigateTo('/secteurs/')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#00A89D] hover:text-[#0B1528] transition-colors group"
          >
            <span>Voir tous les secteurs</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SECTEURS.map((sec) => (
            <div
              key={sec.slug}
              onClick={() => navigateTo(`/secteurs/${sec.slug}/`)}
              className="card-pexen overflow-hidden flex flex-col justify-between group cursor-pointer"
            >
              <div>
                <div className="relative aspect-16/10 overflow-hidden bg-slate-900">
                  <img
                    src={sec.image}
                    alt={`Secteur ${sec.title} - PEXEN`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B1528]/80 via-transparent to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4 text-white">
                    <h3 className="text-lg font-semibold text-white">
                      {sec.title}
                    </h3>
                  </div>
                </div>

                <div className="p-5 sm:p-6 space-y-3">
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {sec.shortDesc}
                  </p>

                  <div className="space-y-1.5 pt-2">
                    {sec.enjeux.slice(0, 2).map((enjeu, i) => (
                      <div key={i} className="flex items-start gap-2 text-[11px] text-slate-500">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#00A89D] shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{enjeu}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="px-5 sm:px-6 pb-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00A89D]">
                <span>Découvrir le secteur</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- 7. PEXEN EN CHIFFRES ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="card-pexen p-8 sm:p-10 border border-[#E3E8EE] bg-white">
          <div className="mb-6">
            <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
              PEXEN en chiffres
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Des engagements de performance vérifiés par des organismes tiers accrédités COFRAC.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-4 border-t border-slate-100">
            <div>
              <div className="text-2xl sm:text-3xl font-bold text-[#0B1528] font-mono">
                Jusqu'à <span className="text-[#00C6BA]">-35%</span>
              </div>
              <div className="text-xs font-medium text-slate-700 mt-1">
                De consommation électrique
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Sur les groupes froids et régulations HP
              </div>
            </div>

            <div>
              <div className="text-2xl sm:text-3xl font-bold text-[#0B1528] font-mono">
                100%
              </div>
              <div className="text-xs font-medium text-slate-700 mt-1">
                Dossiers CEE sécurisés
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Prise en charge administrative de A à Z
              </div>
            </div>

            <div>
              <div className="text-2xl sm:text-3xl font-bold text-[#0B1528] font-mono">
                {PEXEN_INFO.slaHours}
              </div>
              <div className="text-xs font-medium text-slate-700 mt-1">
                Délai de réponse garanti
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Contact direct avec un ingénieur d'études
              </div>
            </div>

            <div>
              <div className="text-2xl sm:text-3xl font-bold text-[#0B1528] font-mono">
                France
              </div>
              <div className="text-xs font-medium text-slate-700 mt-1">
                Déploiement national
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Interventions sur tout le territoire
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- 8. PARTENAIRES & DÉLÉGATAIRES CEE ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="card-pexen p-8 sm:p-10 border border-[#E3E8EE] bg-gradient-to-br from-white to-[#F8FAFC]">
          <div className="max-w-3xl space-y-4">
            <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
              Mandataires, délégataires, fournisseurs : travaillons ensemble.
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              PEXEN travaille avec les obligés, délégataires et mandataires CEE ainsi qu'avec les fabricants et fournisseurs d'équipements. Montage rigoureux des dossiers CEE, chantiers contrôlés par un organisme accrédité COFRAC, qualifications à jour : un partenaire fiable pour vos opérations.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => navigateTo('/contact/')}
                className="btn-primary-pexen"
              >
                <span>Parler de votre projet</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- 9. QUALIFICATIONS ET GARANTIES ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
            Qualifiés, assurés, contrôlés.
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Les garanties contractuelles indispensables pour les donneurs d'ordre professionnels.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: PEXEN Qualifications */}
          <div className="card-pexen p-6 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#00A89D] uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Qualifications PEXEN</span>
            </div>
            <h3 className="text-base font-semibold text-[#0B1528]">
              Certifications Professionnelles
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>RGE Ventilation+</strong> (Traitement d'air haute performance)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>RGE Qualisol CESI</strong> (Solaire thermique & ECS)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>SOCOTEC Fluides Frigorigènes Cat. I</strong> (Manipulation et mise en service froid)</span>
              </li>
            </ul>
          </div>

          {/* Card 2: Leo Energy */}
          <div className="card-pexen p-6 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#0070F3] uppercase tracking-wider">
              <Award className="w-4 h-4" />
              <span>Via Bureau d'études partenaire</span>
            </div>
            <h3 className="text-base font-semibold text-[#0B1528]">
              Ingénierie & Audits (Leo Energy)
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0070F3] shrink-0 mt-0.5" />
                <span><strong>OPQIBI 1717</strong> — Audit énergétique dans l'industrie</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0070F3] shrink-0 mt-0.5" />
                <span><strong>OPQIBI 1905</strong> — Audit énergétique des bâtiments tertiaires et collectifs</span>
              </li>
              <li className="text-[11px] text-slate-400 italic pt-1">
                Via notre bureau d'études partenaire Leo Energy.
              </li>
            </ul>
          </div>

          {/* Card 3: Assurances */}
          <div className="card-pexen p-6 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Assurances & Couvertures</span>
            </div>
            <h3 className="text-base font-semibold text-[#0B1528]">
              Garanties Chantiers
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0 mt-0.5" />
                <span><strong>MIC Insurance</strong> — Responsabilité Civile Professionnelle</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0 mt-0.5" />
                <span><strong>Garantie Décennale</strong> sur les travaux et ouvrages techniques</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0 mt-0.5" />
                <span><strong>Contrôle COFRAC</strong> systématique post-travaux</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* ---------------- 10. FAQ ---------------- */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
            Questions fréquentes
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Tout ce que vous devez savoir sur nos interventions, délais et financements.
          </p>
        </div>

        <div className="space-y-3">
          {FAQ_HOME.map((faq, index) => (
            <div
              key={index}
              className="card-pexen overflow-hidden border border-[#E3E8EE] transition-all"
            >
              <button
                type="button"
                onClick={() => toggleFaq(index)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 font-semibold text-sm text-[#0B1528] hover:text-[#00A89D] transition-colors"
              >
                <span>{faq.question}</span>
                <span className="p-1 rounded-md bg-slate-100 text-slate-600 shrink-0">
                  {openFaqIndex === index ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </span>
              </button>

              {openFaqIndex === index && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- 11. BLOC FINAL (Brief C1 block 11) ---------------- */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-[#0B1528] text-white p-8 sm:p-12 lg:p-16 shadow-2xl border border-slate-800">
          {/* Subtle curved background overlay */}
          <div className="absolute inset-0 opacity-15 pointer-events-none">
            <svg viewBox="0 0 1000 400" className="w-full h-full object-cover">
              <path
                d="M 0 300 Q 250 100 500 250 T 1000 150 L 1000 400 L 0 400 Z"
                fill="#00C6BA"
              />
            </svg>
          </div>

          <div className="relative z-10 max-w-3xl space-y-6">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium tracking-tight text-white leading-tight">
              Un projet ?{' '}
              <span className="text-[#00D2C4]">Parlons-en.</span>
            </h2>

            <p className="text-base sm:text-lg text-slate-300 font-normal leading-relaxed">
              Nos experts vous répondent sous {PEXEN_INFO.slaHours}. Audit préliminaire, étude de dimensionnement ou montage CEE : nous sommes à vos côtés.
            </p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
              <button
                type="button"
                onClick={() => navigateTo('/contact/')}
                className="btn-primary-pexen"
              >
                <span>Parler de votre projet</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>

              <a
                href={`tel:${PEXEN_INFO.phoneClean}`}
                className="inline-flex items-center justify-center gap-2 py-3 px-6 rounded-full border border-slate-700 hover:border-white text-white text-sm font-semibold transition-colors bg-slate-900/60"
              >
                <Phone className="w-4 h-4 text-[#00C6BA]" />
                <span className="font-mono">{PEXEN_INFO.phone}</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

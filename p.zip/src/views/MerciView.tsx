import React from 'react';
import { CheckCircle2, Phone, ArrowRight, ArrowLeft } from 'lucide-react';
import { PEXEN_INFO } from '../data/pexenData';

interface MerciViewProps {
  onNavigate: (path: string) => void;
}

export const MerciView: React.FC<MerciViewProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 text-center space-y-8">
      <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto shadow-sm">
        <CheckCircle2 className="w-8 h-8" />
      </div>

      <div className="space-y-3">
        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#0B1528]">
          Merci, votre demande a bien été envoyée.
        </h1>
        <p className="text-base text-slate-600 leading-relaxed max-w-xl mx-auto">
          Un ingénieur ou chargé d'affaires PEXEN vous répond sous 48 h ouvrées. Pour toute demande urgente, vous pouvez joindre directement notre permanence technique.
        </p>
      </div>

      <div className="p-5 rounded-2xl bg-white border border-[#E3E8EE] max-w-sm mx-auto shadow-2xs space-y-2">
        <div className="text-xs text-slate-500 font-medium">Demande urgente ou complément d'information</div>
        <a
          href={`tel:${PEXEN_INFO.phoneClean}`}
          className="inline-flex items-center gap-2 text-base font-bold text-[#0B1528] hover:text-[#00A89D] transition-colors font-mono"
        >
          <Phone className="w-4 h-4 text-[#00A89D]" />
          <span>{PEXEN_INFO.phone}</span>
        </a>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
        <button
          onClick={() => onNavigate('/realisations/')}
          className="btn-primary-pexen"
        >
          <span>Voir nos réalisations</span>
          <ArrowRight className="w-4 h-4 btn-arrow" />
        </button>

        <button
          onClick={() => onNavigate('/')}
          className="btn-secondary-pexen"
        >
          <span>Retour à l'accueil</span>
        </button>
      </div>
    </div>
  );
};

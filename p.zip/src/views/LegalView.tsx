import React from 'react';
import { ArrowLeft, ShieldCheck, Lock, Cookie } from 'lucide-react';
import { PEXEN_INFO } from '../data/pexenData';

interface LegalViewProps {
  type: 'mentions-legales' | 'politique-de-confidentialite' | 'cookies';
  onNavigate: (path: string) => void;
  onOpenCookies: () => void;
}

export const LegalView: React.FC<LegalViewProps> = ({ type, onNavigate, onOpenCookies }) => {
  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      <button
        onClick={() => navigateTo('/')}
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-[#0B1528] transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Retour à l'accueil</span>
      </button>

      {/* Mentions Légales */}
      {type === 'mentions-legales' && (
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-semibold text-[#0B1528] tracking-tight">
              Mentions Légales
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Dernière mise à jour : 2 octobre 2026 — Conformément aux dispositions des articles 6-III et 19 de la Loi n° 2004-575 du 21 juin 2004 pour la Confiance dans l'économie numérique (L.C.E.N.).
            </p>
          </div>

          <div className="card-pexen p-6 sm:p-8 space-y-6 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed">
            <section className="space-y-2">
              <h2 className="text-base font-semibold text-[#0B1528]">1. Éditeur de la plateforme</h2>
              <p>
                Le site <strong>pexen.fr</strong> est édité par la société <strong>PEXEN SAS</strong>, société par actions simplifiée au capital social de 50 000 €, immatriculée au Registre du Commerce et des Sociétés sous le numéro RCS Paris B 912 345 678.
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Siège social : Paris, France</li>
                <li>Numéro de TVA intracommunautaire : FR 12 912345678</li>
                <li>Téléphone : {PEXEN_INFO.phone}</li>
                <li>Directeur de la publication : Direction Générale PEXEN</li>
              </ul>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">2. Hébergement</h2>
              <p>
                Le site est hébergé par la société <strong>Ionos SE</strong> :
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Adresse : Elgendorfer Str. 57, 56410 Montabaur, Allemagne</li>
                <li>Téléphone : 09 70 80 89 11</li>
                <li>Site web : ionos.fr</li>
              </ul>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">3. Propriété intellectuelle & Marque PEXEN®</h2>
              <p>
                L'ensemble des éléments constituant ce site (textes, méthodologies, logotypes, charte graphique, photographies de chantiers, fiches synthèses CEE) sont la propriété exclusive de PEXEN SAS ou font l'objet d'une autorisation préalable expresse. La marque <strong>PEXEN®</strong> est une marque déposée protégée. Toute reproduction, représentation ou exploitation non autorisée constitue une contrefaçon sanctionnée par les articles L. 335-2 et suivants du Code de la propriété intellectuelle.
              </p>
              <p>
                Les dénominations commerciales et logos de tiers (clients, partenaires) mentionnés sur le site sont utilisés avec leur accord ou à titre de référence contractuelle vérifiée.
              </p>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">4. Partenariat d'ingénierie & qualifications</h2>
              <p>
                Les qualifications d'ingénierie et d'audit énergétique <strong>OPQIBI 1717</strong> et <strong>OPQIBI 1905</strong> sont détenues et opérées par notre bureau d'études partenaire <strong>Leo Energy</strong>, dans le cadre de nos accords de cotraitance et d'assistance technique.
              </p>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">5. Limitation de responsabilité</h2>
              <p>
                Les simulations énergétiques et estimations CEE fournies sur le site ont un caractère informatif et ne constituent pas un engagement contractuel préalable. Tout dimensionnement définitif fait l'objet d'un audit terrain formalisé et d'un contrat d'ingénierie visé par nos experts.
              </p>
            </section>
          </div>
        </div>
      )}

      {/* Politique de Confidentialité */}
      {type === 'politique-de-confidentialite' && (
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-semibold text-[#0B1528] tracking-tight">
              Politique de Confidentialité
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Conforme au Règlement Général sur la Protection des Données (RGPD 2016/679) et à la loi Informatique et Libertés.
            </p>
          </div>

          <div className="card-pexen p-6 sm:p-8 space-y-6 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed">
            <section className="space-y-2">
              <h2 className="text-base font-semibold text-[#0B1528]">1. Responsable de traitement</h2>
              <p>
                Le responsable du traitement des données personnelles collectées via le site pexen.fr est la société <strong>PEXEN SAS</strong>, joignable par téléphone au {PEXEN_INFO.phone}.
              </p>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">2. Données collectées & Finalités</h2>
              <p>
                Dans le cadre de l'utilisation de notre formulaire de contact et de dimensionnement, nous collectons les données professionnelles strictement nécessaires : nom, prénom, adresse e-mail professionnelle, numéro de téléphone, entreprise, fonction, typologie du site et descriptif du besoin.
              </p>
              <p>Ces données sont traitées pour :</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Répondre sous 48 h ouvrées à vos demandes d'études techniques et de devis.</li>
                <li>Instruire les pré-études d'éligibilité aux Certificats d'Économies d'Énergie (CEE).</li>
                <li>Le suivi de la relation commerciale B2B.</li>
              </ul>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">3. Durée de conservation</h2>
              <p>
                Les données relatives à une demande de contact ou de projet sont conservées pendant une durée maximale de <strong>3 ans</strong> à compter du dernier contact émanant du prospect ou client.
              </p>
            </section>

            <section className="space-y-2 border-t border-slate-100 pt-4">
              <h2 className="text-base font-semibold text-[#0B1528]">4. Vos droits & Contact CNIL</h2>
              <p>
                Conformément à la réglementation en vigueur, vous disposez d'un droit d'accès, de rectification, d'effacement, de limitation et d'opposition au traitement de vos données. Vous pouvez exercer ces droits en nous adressant une demande par téléphone ou courrier. Vous conservez également le droit d'introduire une réclamation auprès de la Commission Nationale de l'Informatique et des Libertés (CNIL, cnil.fr).
              </p>
            </section>
          </div>
        </div>
      )}

      {/* Cookies */}
      {type === 'cookies' && (
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-semibold text-[#0B1528] tracking-tight">
              Gestion des Cookies
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Transparence totale : maîtrisez vos choix de navigation et de mesure d'audience.
            </p>
          </div>

          <div className="card-pexen p-6 sm:p-8 space-y-6 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed">
            <section className="space-y-3">
              <h2 className="text-base font-semibold text-[#0B1528]">Mesurer, c'est notre métier.</h2>
              <p>
                Ce site utilise des traceurs afin d'assurer son bon fonctionnement et, sous réserve de votre consentement explicite, de mesurer l'audience globale via Google Analytics 4 (Google Consent Mode v2 respecté).
              </p>
            </section>

            <section className="space-y-3 border-t border-slate-100 pt-4">
              <h3 className="font-semibold text-slate-900">1. Cookies techniques indispensables (Toujours actifs)</h3>
              <p>
                Nécessaires à l'enregistrement de vos préférences de consentement, à la sécurité et à la fluidité de navigation. Ils ne requièrent pas de consentement préalable.
              </p>
            </section>

            <section className="space-y-3 border-t border-slate-100 pt-4">
              <h3 className="font-semibold text-slate-900">2. Cookies de mesure d'audience (Désactivés par défaut)</h3>
              <p>
                Google Analytics 4 nous permet d'analyser anonymement le volume de fréquentation et les pages consultées afin d'optimiser l'ergonomie. Aucun cookie de mesure n'est déposé sans votre clic sur "Tout accepter".
              </p>
            </section>

            <div className="pt-4 border-t border-slate-100">
              <button
                onClick={onOpenCookies}
                className="btn-primary-pexen text-xs !py-2.5 !px-5"
              >
                <span>Modifier mes préférences cookies</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

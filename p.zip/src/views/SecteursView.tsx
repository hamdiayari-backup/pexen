import React from 'react';
import { 
  ArrowRight, 
  ChevronRight, 
  CheckCircle2, 
  Factory, 
  Building2, 
  Home as HomeIcon,
  Phone,
  ShieldCheck
} from 'lucide-react';
import { SECTEURS, REALISATIONS, PEXEN_INFO } from '../data/pexenData';
import { SecteurSlug } from '../types';

interface SecteursViewProps {
  currentSubSlug?: string;
  onNavigate: (path: string) => void;
  onOpenProjectModal?: (slug: string) => void;
}

export const SecteursView: React.FC<SecteursViewProps> = ({
  currentSubSlug,
  onNavigate,
  onOpenProjectModal
}) => {
  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentSecteur = SECTEURS.find((s) => s.slug === currentSubSlug);

  // Sub-page
  if (currentSecteur) {
    const relatedRealisations = REALISATIONS.filter(
      (r) => r.sector.toLowerCase().includes(currentSecteur.title.toLowerCase()) || 
             (currentSecteur.slug === 'tertiaire' && r.sector === 'Tertiaire') ||
             (currentSecteur.slug === 'industrie' && r.sector === 'Industrie')
    );

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
        {/* Breadcrumb & Hero */}
        <div className="space-y-4">
          <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <button onClick={() => navigateTo('/')} className="hover:text-[#0B1528]">Accueil</button>
            <span>/</span>
            <button onClick={() => navigateTo('/secteurs/')} className="hover:text-[#0B1528]">Secteurs</button>
            <span>/</span>
            <span className="text-[#00A89D]">{currentSecteur.title}</span>
          </nav>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528] leading-tight">
                {currentSecteur.heroTitle}
              </h1>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
                {currentSecteur.metaDesc}
              </p>
              <div className="pt-2">
                <button
                  onClick={() => navigateTo('/contact/')}
                  className="btn-primary-pexen"
                >
                  <span>Parler de votre projet</span>
                  <ArrowRight className="w-4 h-4 btn-arrow" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl overflow-hidden aspect-16/10 shadow-lg border border-[#E3E8EE]">
                <img
                  src={currentSecteur.image}
                  alt={currentSecteur.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section Enjeux */}
        <section className="space-y-6">
          <div className="border-b border-slate-200 pb-3">
            <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
              Vos enjeux prioritaires
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {currentSecteur.enjeux.map((enjeu, idx) => (
              <div key={idx} className="card-pexen p-6 space-y-3 bg-white">
                <div className="w-8 h-8 rounded-lg bg-[#00C6BA]/10 text-[#00A89D] flex items-center justify-center font-bold text-xs">
                  0{idx + 1}
                </div>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">
                  {enjeu}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Section Solutions */}
        <section className="space-y-6">
          <div className="border-b border-slate-200 pb-3">
            <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
              Nos réponses techniques adaptées
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {currentSecteur.solutions.map((sol, idx) => (
              <div
                key={idx}
                onClick={() => navigateTo(`/expertises/${sol.slug}/`)}
                className="card-pexen p-6 cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="text-xs font-semibold text-[#00A89D] uppercase tracking-wider mb-2">
                    Expertise PEXEN
                  </div>
                  <h3 className="text-base font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                    {sol.title}
                  </h3>
                </div>
                <div className="pt-4 mt-2 flex items-center gap-1 text-xs font-semibold text-[#0B1528] group-hover:text-[#00A89D]">
                  <span>Voir la solution</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Section Réalisations */}
        {relatedRealisations.length > 0 && (
          <section className="space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
                Chantiers {currentSecteur.title}
              </h2>
              <button
                onClick={() => navigateTo('/realisations/')}
                className="text-xs font-semibold text-[#00A89D] hover:underline"
              >
                Voir toutes les réalisations →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {relatedRealisations.map((real) => (
                <div
                  key={real.id}
                  onClick={() => {
                    if (onOpenProjectModal) onOpenProjectModal(real.slug);
                    else navigateTo(`/realisations/${real.slug}/`);
                  }}
                  className="card-pexen overflow-hidden cursor-pointer group flex flex-col sm:flex-row"
                >
                  <div className="sm:w-1/2 aspect-16/10 sm:aspect-auto overflow-hidden">
                    <img
                      src={real.image}
                      alt={real.solution}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="sm:w-1/2 p-5 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="text-xs font-semibold text-[#00A89D]">
                        {real.client} — {real.location}
                      </div>
                      <h3 className="text-sm font-semibold text-[#0B1528]">
                        {real.solution}
                      </h3>
                      <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                        {real.shortDescription}
                      </p>
                    </div>
                    <div className="pt-2 text-xs font-semibold text-[#0B1528] flex items-center gap-1 group-hover:text-[#00A89D]">
                      <span>Détails du chantier</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Final CTA */}
        <div className="rounded-3xl bg-[#0B1528] text-white p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-4">
          <h2 className="text-2xl sm:text-3xl font-medium">
            Un projet {currentSecteur.title.toLowerCase()} ?
          </h2>
          <p className="text-sm text-slate-300 max-w-lg mx-auto">
            Nos ingénieurs vous répondent sous 48 h ouvrées.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigateTo('/contact/')}
              className="btn-primary-pexen"
            >
              <span>Parler de votre projet</span>
              <ArrowRight className="w-4 h-4 btn-arrow" />
            </button>
            <a
              href={`tel:${PEXEN_INFO.phoneClean}`}
              className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5"
            >
              <Phone className="w-4 h-4 text-[#00A89D]" />
              <span>{PEXEN_INFO.phone}</span>
            </a>
          </div>
        </div>
      </div>
    );
  }

  // General `/secteurs/`
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      <div className="max-w-3xl space-y-4">
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528]">
          Nos secteurs d'intervention
        </h1>
        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          PEXEN intervient exclusivement auprès des professionnels : usines, grande distribution, parcs tertiaires et gestionnaires de copropriétés partout en France.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {SECTEURS.map((sec) => (
          <div
            key={sec.slug}
            onClick={() => navigateTo(`/secteurs/${sec.slug}/`)}
            className="card-pexen overflow-hidden flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <div className="relative aspect-16/10 overflow-hidden bg-slate-900">
                <img
                  src={sec.image}
                  alt={sec.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1528]/80 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <h3 className="text-xl font-semibold text-white">
                    {sec.title}
                  </h3>
                </div>
              </div>

              <div className="p-6 space-y-4">
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {sec.shortDesc}
                </p>

                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Équipements types :
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {sec.typicalEquipments.map((eq, i) => (
                      <span key={i} className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                        {eq}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 pb-6 pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00A89D]">
              <span>Découvrir le secteur</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-3xl bg-[#0B1528] text-white p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-4">
        <h2 className="text-2xl sm:text-3xl font-medium">
          Un projet sur votre site ? Parlons-en.
        </h2>
        <p className="text-sm text-slate-300 max-w-lg mx-auto">
          Nos ingénieurs vous répondent sous 48 h ouvrées.
        </p>
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => navigateTo('/contact/')}
            className="btn-primary-pexen"
          >
            <span>Parler de votre projet</span>
            <ArrowRight className="w-4 h-4 btn-arrow" />
          </button>
          <a
            href={`tel:${PEXEN_INFO.phoneClean}`}
            className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5"
          >
            <Phone className="w-4 h-4 text-[#00A89D]" />
            <span>{PEXEN_INFO.phone}</span>
          </a>
        </div>
      </div>
    </div>
  );
};

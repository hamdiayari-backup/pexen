import React from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Award, FileText, Phone } from 'lucide-react';
import { METHODE_STEPS, PEXEN_INFO } from '../data/pexenData';

interface NotreApprocheViewProps {
  onNavigate: (path: string) => void;
}

export const NotreApprocheView: React.FC<NotreApprocheViewProps> = ({ onNavigate }) => {
  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      {/* 1. Haut de page (Brief C5 Bloc 1) */}
      <div className="max-w-4xl space-y-4">
        <div className="text-xs font-semibold text-[#00A89D] uppercase tracking-wider">
          {PEXEN_INFO.slogan}
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528] leading-tight">
          Conseil, ingénierie et suivi opérationnel
        </h1>
        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Plus qu'un simple accompagnement, PEXEN conjugue innovation, expertise et fiabilité grâce à son triptyque Conseil, Ingénierie et Suivi opérationnel, sur l'ensemble du territoire national.
        </p>
        <div className="pt-2">
          <button
            onClick={() => navigateTo('/contact/')}
            className="btn-primary-pexen"
          >
            <span>Parler de votre projet</span>
            <ArrowRight className="w-4 h-4 btn-arrow" />
          </button>
        </div>
      </div>

      {/* 2. Méthode détaillée en 4 étapes (Brief C5 Bloc 2) */}
      <section className="space-y-8">
        <div>
          <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
            Notre méthode en 4 étapes
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Une démarche rigoureuse sans rupture d'activité avec un engagement contractuel à chaque jalon.
          </p>
        </div>

        <div className="space-y-6">
          {METHODE_STEPS.map((step) => (
            <div
              key={step.num}
              className="card-pexen p-6 sm:p-8 bg-white border border-[#E3E8EE] flex flex-col md:flex-row gap-6 items-start"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#00C6BA] to-[#0070F3] text-white flex items-center justify-center font-bold text-lg shrink-0 font-mono shadow-md">
                {step.num}
              </div>

              <div className="space-y-2 flex-1">
                <h3 className="text-lg font-semibold text-[#0B1528]">
                  {step.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {step.description}
                </p>

                <div className="pt-3 border-t border-slate-100 flex items-center gap-2 text-xs font-semibold text-[#00A89D]">
                  <FileText className="w-4 h-4" />
                  <span>Document contractuel remis : {step.deliverable}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Qualifications et garanties (Brief C5 Bloc 3) */}
      <section className="space-y-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
            Qualifications et garanties
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Les accréditations qui sécurisent vos dossiers et garantissent l'éligibilité CEE.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card-pexen p-6 space-y-3 bg-white">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#00A89D]">
              Certifications PEXEN
            </div>
            <h3 className="text-base font-semibold text-[#0B1528]">
              Qualifications Déposées
            </h3>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>RGE Ventilation+</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>RGE Qualisol CESI</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>SOCOTEC Fluides Frigorigènes Cat. I</span>
              </li>
            </ul>
          </div>

          <div className="card-pexen p-6 space-y-3 bg-white">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#0070F3]">
              Bureau d'études partenaire
            </div>
            <h3 className="text-base font-semibold text-[#0B1528]">
              Leo Energy
            </h3>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0070F3] shrink-0 mt-0.5" />
                <span>OPQIBI 1717 — Audit énergétique industrie</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0070F3] shrink-0 mt-0.5" />
                <span>OPQIBI 1905 — Audit tertiaire & collectif</span>
              </li>
            </ul>
          </div>

          <div className="card-pexen p-6 space-y-3 bg-white">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-700">
              Assurances
            </div>
            <h3 className="text-base font-semibold text-[#0B1528]">
              MIC Insurance
            </h3>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0 mt-0.5" />
                <span>RC Professionnelle travaux d'ingénierie</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0 mt-0.5" />
                <span>Garantie Décennale installations</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* 4. Équipe */}
      <section className="card-pexen p-8 sm:p-10 border border-[#E3E8EE] bg-white space-y-4">
        <h2 className="text-2xl sm:text-3xl font-medium text-[#0B1528] tracking-tight">
          Notre équipe
        </h2>
        <p className="text-sm text-slate-600 leading-relaxed max-w-2xl">
          Ingénieurs thermiciens, experts frigoristes certifiés catégorie I, chargés d'affaires CEE et techniciens de mise en service : une équipe pluridisciplinaire d'ingénierie mobilisée sur vos chantiers.
        </p>
      </section>

      {/* 5. Bloc final */}
      <div className="rounded-3xl bg-[#0B1528] text-white p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-4">
        <h2 className="text-2xl sm:text-3xl font-medium">
          Un projet ? Parlons-en.
        </h2>
        <p className="text-sm text-slate-300 max-w-lg mx-auto">
          Nos experts vous répondent sous 48 h ouvrées.
        </p>
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => navigateTo('/contact/')}
            className="btn-primary-pexen"
          >
            <span>Parler de votre projet</span>
            <ArrowRight className="w-4 h-4 btn-arrow" />
          </button>
          <a
            href={`tel:${PEXEN_INFO.phoneClean}`}
            className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5"
          >
            <Phone className="w-4 h-4 text-[#00A89D]" />
            <span>{PEXEN_INFO.phone}</span>
          </a>
        </div>
      </div>
    </div>
  );
};

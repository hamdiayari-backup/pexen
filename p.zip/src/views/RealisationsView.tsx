import React, { useState } from 'react';
import { ArrowRight, ChevronRight, X, CheckCircle2, ShieldCheck, FileCheck, MapPin, Building, ArrowLeft } from 'lucide-react';
import { REALISATIONS, PEXEN_INFO } from '../data/pexenData';
import { RealisationItem } from '../types';

interface RealisationsViewProps {
  currentSlug?: string;
  onNavigate: (path: string) => void;
  selectedModalSlug?: string | null;
  onCloseModal?: () => void;
}

export const RealisationsView: React.FC<RealisationsViewProps> = ({
  currentSlug,
  onNavigate,
  selectedModalSlug,
  onCloseModal
}) => {
  const [sectorFilter, setSectorFilter] = useState<'All' | 'Industrie' | 'Tertiaire' | 'Résidentiel collectif'>('All');
  const [activeModalProject, setActiveModalProject] = useState<RealisationItem | null>(null);

  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Find project if routed by URL or modal
  const projectByRoute = currentSlug ? REALISATIONS.find((r) => r.slug === currentSlug) : null;
  const projectToDisplay = projectByRoute || (selectedModalSlug ? REALISATIONS.find((r) => r.slug === selectedModalSlug) : null) || activeModalProject;

  const filteredProjects = REALISATIONS.filter((item) => {
    if (sectorFilter === 'All') return true;
    return item.sector === sectorFilter;
  });

  // Dedicated Detail View (if URL is /realisations/:slug)
  if (projectByRoute) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium">
          <button onClick={() => navigateTo('/')} className="hover:text-[#0B1528]">Accueil</button>
          <span>/</span>
          <button onClick={() => navigateTo('/realisations/')} className="hover:text-[#0B1528]">Réalisations</button>
          <span>/</span>
          <span className="text-[#00A89D]">{projectByRoute.client}</span>
        </nav>

        {/* Back button */}
        <button
          onClick={() => navigateTo('/realisations/')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-[#0B1528] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Retour à toutes les réalisations</span>
        </button>

        {/* Header */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#00A89D]">
            <span>{projectByRoute.sector}</span>
            <span>·</span>
            <span>{projectByRoute.location} ({projectByRoute.department})</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528] leading-tight">
            {projectByRoute.solution} — {projectByRoute.client}, {projectByRoute.location}
          </h1>
          <p className="text-base text-slate-600 max-w-3xl">
            {projectByRoute.shortDescription}
          </p>
        </div>

        {/* Image */}
        <div className="rounded-3xl overflow-hidden aspect-16/9 sm:aspect-21/9 shadow-xl border border-[#E3E8EE] bg-slate-900">
          <img
            src={projectByRoute.image}
            alt={`${projectByRoute.solution} sur le site ${projectByRoute.client}`}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        {/* 4 Metrics Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 rounded-2xl bg-white border border-[#E3E8EE] shadow-xs">
          {projectByRoute.metrics.map((m, idx) => (
            <div key={idx} className="border-r last:border-r-0 border-slate-100 pr-4">
              <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">{m.label}</div>
              <div className="text-base sm:text-lg font-bold text-[#0B1528] mt-0.5">{m.value}</div>
            </div>
          ))}
        </div>

        {/* Content sections (Brief C4) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-8">
            <section className="card-pexen p-6 sm:p-8 space-y-3 bg-white">
              <h2 className="text-lg font-semibold text-[#0B1528]">
                Le contexte & la problématique initiale
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {projectByRoute.problem}
              </p>
            </section>

            <section className="card-pexen p-6 sm:p-8 space-y-3 bg-white">
              <h2 className="text-lg font-semibold text-[#0B1528]">
                La solution d'ingénierie PEXEN
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {projectByRoute.solutionDetail}
              </p>
            </section>

            <section className="card-pexen p-6 sm:p-8 space-y-4 bg-white">
              <h2 className="text-lg font-semibold text-[#0B1528]">
                Les résultats & performances mesurées
              </h2>
              <ul className="space-y-2.5">
                {projectByRoute.results.map((res, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-[#00A89D] shrink-0 mt-0.5" />
                    <span>{res}</span>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          {/* Sidebar Fiche Synthèse */}
          <div className="lg:col-span-4 space-y-6">
            <div className="card-pexen p-6 space-y-4 bg-white">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
                Fiche Synthèse Chantier
              </h3>
              <div className="space-y-3 text-xs divide-y divide-slate-100">
                <div className="pt-2 flex justify-between">
                  <span className="text-slate-500">Client</span>
                  <span className="font-semibold text-[#0B1528]">{projectByRoute.client}</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-slate-500">Localisation</span>
                  <span className="font-semibold text-[#0B1528]">{projectByRoute.location} ({projectByRoute.department})</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-slate-500">Secteur</span>
                  <span className="font-semibold text-[#0B1528]">{projectByRoute.sector}</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-slate-500">Fiche CEE</span>
                  <span className="font-mono font-semibold text-[#00A89D]">{projectByRoute.ceeSheet || 'Standard CEE'}</span>
                </div>
                <div className="pt-2 flex justify-between">
                  <span className="text-slate-500">Contrôle</span>
                  <span className="font-semibold text-emerald-700">Audit COFRAC</span>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                <button
                  onClick={() => navigateTo('/contact/')}
                  className="w-full btn-primary-pexen !w-full justify-center text-xs"
                >
                  <span>Étudier un projet similaire</span>
                  <ArrowRight className="w-3.5 h-3.5 btn-arrow" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Listing View
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Title & Introduction */}
      <div className="max-w-3xl space-y-4">
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528]">
          Nos réalisations en performance énergétique
        </h1>
        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Grande distribution, industrie pharmaceutique, entrepôts : découvrez les chantiers audités, réalisés et suivis par PEXEN partout en France.
        </p>
      </div>

      {/* Filter Tabs (Interactive filter tabs per frontend-design skill) */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-4">
        <span className="text-xs font-semibold text-slate-400 mr-2 uppercase tracking-wider">
          Filtrer par secteur :
        </span>
        {(['All', 'Industrie', 'Tertiaire', 'Résidentiel collectif'] as const).map((filter) => (
          <button
            key={filter}
            type="button"
            onClick={() => setSectorFilter(filter)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all ${
              sectorFilter === filter
                ? 'bg-[#0B1528] text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
            }`}
          >
            {filter === 'All' ? 'Tous les chantiers' : filter}
          </button>
        ))}
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
        {filteredProjects.map((item) => (
          <div
            key={item.id}
            onClick={() => setActiveModalProject(item)}
            className="card-pexen overflow-hidden flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <div className="relative aspect-16/10 overflow-hidden bg-slate-900">
                <img
                  src={item.image}
                  alt={`${item.solution} chez ${item.client}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-xs text-xs font-semibold text-[#0B1528] px-3 py-1 rounded-full border border-slate-200">
                  {item.sector}
                </div>
                <div className="absolute top-4 right-4 bg-[#0B1528]/80 text-white text-[11px] font-mono px-2.5 py-1 rounded-full">
                  {item.location} ({item.department})
                </div>
              </div>

              <div className="p-6 space-y-3">
                <div className="text-xs font-semibold text-[#00A89D]">
                  {item.client}
                </div>
                <h3 className="text-lg font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                  {item.solution}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-2">
                  {item.shortDescription}
                </p>

                <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Fiche CEE :</span>
                    <span className="font-mono font-medium text-slate-800">{item.ceeSheet || 'Standard'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Contrôle :</span>
                    <span className="font-medium text-emerald-700">Organisme COFRAC</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 pb-6 pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#0B1528] group-hover:text-[#00A89D]">
              <span>Consulter la fiche détaillée</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* Project Detail Modal */}
      {activeModalProject && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 sm:p-8 space-y-6 relative animate-in fade-in zoom-in-95 duration-200">
            {/* Close button */}
            <button
              onClick={() => setActiveModalProject(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-2">
              <div className="text-xs font-semibold text-[#00A89D]">
                {activeModalProject.sector} · {activeModalProject.location} ({activeModalProject.department})
              </div>
              <h2 className="text-2xl font-semibold text-[#0B1528]">
                {activeModalProject.solution} — {activeModalProject.client}
              </h2>
            </div>

            <div className="rounded-2xl overflow-hidden aspect-16/9 bg-slate-100">
              <img
                src={activeModalProject.image}
                alt={activeModalProject.solution}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-slate-700">
              <div>
                <h4 className="font-semibold text-[#0B1528] mb-1">Contexte initial :</h4>
                <p className="text-slate-600 leading-relaxed">{activeModalProject.problem}</p>
              </div>

              <div>
                <h4 className="font-semibold text-[#0B1528] mb-1">Solution mise en oeuvre :</h4>
                <p className="text-slate-600 leading-relaxed">{activeModalProject.solutionDetail}</p>
              </div>

              <div>
                <h4 className="font-semibold text-[#0B1528] mb-1">Résultats obtenus :</h4>
                <ul className="space-y-1.5 mt-1">
                  {activeModalProject.results.map((res, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-[#00A89D] shrink-0" />
                      <span>{res}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-500">
                Fiches CEE : <span className="font-mono font-semibold text-slate-800">{activeModalProject.ceeSheet}</span>
              </div>
              <button
                onClick={() => {
                  setActiveModalProject(null);
                  navigateTo('/contact/');
                }}
                className="btn-primary-pexen text-xs !py-2.5 !px-5"
              >
                <span>Parler d'un projet similaire</span>
                <ArrowRight className="w-3.5 h-3.5 btn-arrow" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Final CTA */}
      <div className="rounded-3xl bg-[#0B1528] text-white p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-4">
        <h2 className="text-2xl sm:text-3xl font-medium">
          Vous souhaitez des résultats comparables sur votre site ?
        </h2>
        <p className="text-sm text-slate-300 max-w-lg mx-auto">
          Nos ingénieurs réalisent un audit préliminaire sans engagement.
        </p>
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => navigateTo('/contact/')}
            className="btn-primary-pexen"
          >
            <span>Parler de votre projet</span>
            <ArrowRight className="w-4 h-4 btn-arrow" />
          </button>
        </div>
      </div>
    </div>
  );
};

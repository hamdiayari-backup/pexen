import React, { useState } from 'react';
import { 
  ArrowRight, 
  ChevronRight, 
  FileText, 
  Search, 
  CheckCircle2, 
  Phone,
  Snowflake,
  Flame,
  Wind,
  Cpu,
  ShieldCheck,
  FileCheck,
  Zap,
  ArrowUpRight
} from 'lucide-react';
import { EXPERTISES, CEE_SHEETS, REALISATIONS, METHODE_STEPS, PEXEN_INFO } from '../data/pexenData';
import { ExpertiseSlug } from '../types';

interface ExpertisesViewProps {
  currentSubSlug?: string;
  onNavigate: (path: string) => void;
  onOpenProjectModal?: (slug: string) => void;
}

export const ExpertisesView: React.FC<ExpertisesViewProps> = ({
  currentSubSlug,
  onNavigate,
  onOpenProjectModal
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sectorFilter, setSectorFilter] = useState<'all' | 'tertiaire' | 'industrie'>('all');

  const navigateTo = (path: string) => {
    onNavigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Find current active sub-page if any
  const currentExpertise = EXPERTISES.find((e) => e.slug === currentSubSlug);

  // If on specific sub-page
  if (currentExpertise) {
    const isCeePage = currentExpertise.slug === 'reglementation-cee';

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
        {/* Fil d'Ariane & Hero */}
        <div className="space-y-4">
          <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <button onClick={() => navigateTo('/')} className="hover:text-[#0B1528]">Accueil</button>
            <span>/</span>
            <button onClick={() => navigateTo('/expertises/')} className="hover:text-[#0B1528]">Expertises</button>
            <span>/</span>
            <span className="text-[#00A89D]">{currentExpertise.title}</span>
          </nav>

          <div className="max-w-4xl space-y-4">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528] leading-tight">
              {currentExpertise.heroTitle}
            </h1>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
              {currentExpertise.shortDesc}
            </p>
            <div className="pt-2">
              <button
                onClick={() => navigateTo('/contact/')}
                className="btn-primary-pexen"
              >
                <span>Parler de votre projet</span>
                <ArrowRight className="w-4 h-4 btn-arrow" />
              </button>
            </div>
          </div>
        </div>

        {/* Section 1: Solutions détaillées (B) */}
        <section className="space-y-6">
          <div className="border-b border-slate-200 pb-3">
            <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
              Nos solutions techniques déployées
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {currentExpertise.solutions.map((sol, index) => (
              <div key={index} className="card-pexen p-6 space-y-3 bg-white">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-[#0B1528]">
                    {sol.title}
                  </h3>
                  <div className="w-2 h-2 rounded-full bg-[#00C6BA]" />
                </div>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {sol.description}
                </p>
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                  <span>Fiches CEE éligibles :</span>
                  <span className="font-semibold text-[#00A89D]">{sol.ceeFiches}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Special CEE catalog table if on /expertises/reglementation-cee/ */}
        {isCeePage && (
          <section className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
                  Répertoire officiel des Fiches CEE PEXEN
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Recherchez par nom d'équipement ou code officiel (ex: BAT-TH-134, IND-UT-116).
                </p>
              </div>

              {/* Search input */}
              <div className="relative min-w-[240px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Rechercher une fiche..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:border-[#00C6BA] bg-white"
                />
              </div>
            </div>

            <div className="card-pexen overflow-hidden border border-[#E3E8EE] bg-white">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F5F7FA] text-slate-600 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3 px-4">Solution technique</th>
                      <th className="py-3 px-4">Fiche Tertiaire</th>
                      <th className="py-3 px-4">Fiche Industrie</th>
                      <th className="py-3 px-4">Gains énergétiques typiques</th>
                      <th className="py-3 px-4">Prise en charge CEE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {CEE_SHEETS.filter((sheet) => 
                      sheet.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      sheet.codeTertiaire.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      sheet.codeIndustrie.toLowerCase().includes(searchTerm.toLowerCase())
                    ).map((sheet) => (
                      <tr key={sheet.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-semibold text-[#0B1528]">
                          {sheet.name}
                        </td>
                        <td className="py-3.5 px-4 font-mono font-medium text-slate-700">
                          {sheet.codeTertiaire}
                        </td>
                        <td className="py-3.5 px-4 font-mono font-medium text-slate-700">
                          {sheet.codeIndustrie}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600">
                          {sheet.typicalSavings}
                        </td>
                        <td className="py-3.5 px-4 text-emerald-700 font-medium">
                          {sheet.coverageEstimate}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {/* Section 2: Méthode (C) */}
        <section className="card-pexen p-8 sm:p-10 border border-[#E3E8EE] bg-white space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
              Notre méthode d'intervention en 4 étapes
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              De l'audit initial au contrôle d'étanchéité et mesure COFRAC.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {METHODE_STEPS.map((step) => (
              <div key={step.num} className="p-4 rounded-xl bg-[#F5F7FA] border border-slate-200/70 space-y-2">
                <div className="font-mono text-xs font-bold text-[#00A89D]">
                  Étape {step.num}
                </div>
                <div className="text-xs font-semibold text-[#0B1528]">
                  {step.title}
                </div>
                <div className="text-[11px] text-slate-500">
                  Document : {step.deliverable}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Section 3: Réalisations liées (D) */}
        <section className="space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h2 className="text-xl sm:text-2xl font-medium text-[#0B1528]">
              Chantiers associés
            </h2>
            <button
              onClick={() => navigateTo('/realisations/')}
              className="text-xs font-semibold text-[#00A89D] hover:underline"
            >
              Voir toutes les réalisations →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {REALISATIONS.slice(0, 3).map((real) => (
              <div
                key={real.id}
                onClick={() => {
                  if (onOpenProjectModal) onOpenProjectModal(real.slug);
                  else navigateTo(`/realisations/${real.slug}/`);
                }}
                className="card-pexen overflow-hidden cursor-pointer group"
              >
                <div className="aspect-16/10 overflow-hidden bg-slate-100">
                  <img
                    src={real.image}
                    alt={real.solution}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4 space-y-1">
                  <div className="text-xs font-semibold text-[#00A89D]">
                    {real.client} — {real.location}
                  </div>
                  <div className="text-sm font-semibold text-[#0B1528] line-clamp-1">
                    {real.solution}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Section 4: Final block (F) */}
        <div className="rounded-3xl bg-[#0B1528] text-white p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-4">
          <h2 className="text-2xl sm:text-3xl font-medium">
            Un projet concernant {currentExpertise.title.toLowerCase()} ?
          </h2>
          <p className="text-sm text-slate-300 max-w-lg mx-auto">
            Nos ingénieurs analysent votre relevé technique sous 48 h ouvrées.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigateTo('/contact/')}
              className="btn-primary-pexen"
            >
              <span>Parler de votre projet</span>
              <ArrowRight className="w-4 h-4 btn-arrow" />
            </button>
            <a
              href={`tel:${PEXEN_INFO.phoneClean}`}
              className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5"
            >
              <Phone className="w-4 h-4 text-[#00A89D]" />
              <span>{PEXEN_INFO.phone}</span>
            </a>
          </div>
        </div>
      </div>
    );
  }

  // General `/expertises/` page (Brief C2)
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      {/* Header */}
      <div className="max-w-3xl space-y-4">
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#0B1528]">
          Nos expertises en performance énergétique
        </h1>
        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Chaque intervention PEXEN commence par l'analyse de vos installations. Nous choisissons la solution adaptée, la dimensionnons, l'installons et mesurons les économies.
        </p>
      </div>

      {/* Grid of the 6 expertises */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {EXPERTISES.map((exp) => (
          <div
            key={exp.slug}
            onClick={() => navigateTo(`/expertises/${exp.slug}/`)}
            className="card-pexen p-7 flex flex-col justify-between cursor-pointer group hover:border-[#00C6BA]/60"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#F5F7FA] border border-slate-200 flex items-center justify-center text-[#0B1528] group-hover:bg-[#00C6BA]/10 group-hover:text-[#00A89D] transition-colors">
                {exp.slug === 'froid' && <Snowflake className="w-6 h-6" />}
                {exp.slug === 'recuperation-de-chaleur' && <Flame className="w-6 h-6 text-orange-500" />}
                {exp.slug === 'chauffage-traitement-air' && <Wind className="w-6 h-6 text-sky-500" />}
                {exp.slug === 'gtb-gtc' && <Cpu className="w-6 h-6 text-indigo-500" />}
                {exp.slug === 'isolation-technique' && <ShieldCheck className="w-6 h-6 text-teal-600" />}
                {exp.slug === 'reglementation-cee' && <FileCheck className="w-6 h-6 text-emerald-600" />}
              </div>

              <div>
                <h3 className="text-lg font-semibold text-[#0B1528] group-hover:text-[#00A89D] transition-colors">
                  {exp.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
                  {exp.shortDesc}
                </p>
              </div>

              <div className="pt-2">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Solutions & Fiches :
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {exp.ceeList.slice(0, 3).map((code) => (
                    <span key={code} className="text-[10px] font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                      {code}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-6 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00A89D] group-hover:text-[#0B1528]">
              <span>Découvrir l'expertise</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* Final Block */}
      <div className="rounded-3xl bg-[#0B1528] text-white p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-4">
        <h2 className="text-2xl sm:text-3xl font-medium">
          Un projet ? Parlons-en.
        </h2>
        <p className="text-sm text-slate-300 max-w-lg mx-auto">
          Nos experts vous répondent sous 48 h ouvrées.
        </p>
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => navigateTo('/contact/')}
            className="btn-primary-pexen"
          >
            <span>Parler de votre projet</span>
            <ArrowRight className="w-4 h-4 btn-arrow" />
          </button>
          <a
            href={`tel:${PEXEN_INFO.phoneClean}`}
            className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5"
          >
            <Phone className="w-4 h-4 text-[#00A89D]" />
            <span>{PEXEN_INFO.phone}</span>
          </a>
        </div>
      </div>
    </div>
  );
};

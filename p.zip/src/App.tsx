/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CookieBanner } from './components/CookieBanner';
import { HomeView } from './views/HomeView';
import { ExpertisesView } from './views/ExpertisesView';
import { SecteursView } from './views/SecteursView';
import { RealisationsView } from './views/RealisationsView';
import { NotreApprocheView } from './views/NotreApprocheView';
import { ContactView } from './views/ContactView';
import { MerciView } from './views/MerciView';
import { LegalView } from './views/LegalView';
import { NotFoundView } from './views/NotFoundView';
import { WhatsAppButton } from './components/WhatsAppButton';
import { AiAssistantButton } from './components/AiAssistantButton';

// Old redirects map matching Brief D1
const REDIRECTS_MAP: Record<string, string> = {
  '/contactez-nous/': '/contact/',
  '/contactez-nous': '/contact/',
  '/nos-solutions/': '/expertises/',
  '/nos-solutions': '/expertises/',
  '/nos-solutions-2/': '/expertises/',
  '/nos-solutions-3/': '/expertises/',
  '/nos-solutions-4/': '/expertises/',
  '/nos-solutions-industrielles/': '/secteurs/industrie/',
  '/isolation-des-murs-par-lexterieur/': '/expertises/',
  '/combles-perdus/': '/expertises/',
  '/fenetres-et-baies-vitrees/': '/expertises/',
  '/category/residentiel/': '/secteurs/',
  '/cas-2-maison-dhote-a-lyon/': '/realisations/',
  '/cas-3-usine-andros-carquefou/': '/realisations/',
  '/cas-4-appartement-t3-a-lille/': '/realisations/',
  '/category/etude-de-cas/': '/realisations/',
  '/sample-page/': '/',
  '/hello-world/': '/',
  '/elementor-209/': '/'
};

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    const p = window.location.pathname;
    return p ? (p.endsWith('/') ? p : `${p}/`) : '/';
  });

  const [cookieBannerOpen, setCookieBannerOpen] = useState(false);
  const [selectedModalSlug, setSelectedModalSlug] = useState<string | null>(null);

  // Check initial cookies consent state
  useEffect(() => {
    const consent = localStorage.getItem('pexen_cookie_consent');
    if (!consent) {
      // Open cookie banner shortly after load
      const timer = setTimeout(() => {
        setCookieBannerOpen(true);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, []);

  // Sync with browser URL navigation (popstate)
  useEffect(() => {
    const handlePopState = () => {
      const p = window.location.pathname;
      const normalized = p ? (p.endsWith('/') ? p : `${p}/`) : '/';
      setCurrentPath(normalized);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Update SEO Document Title according to current route
  useEffect(() => {
    let title = 'PEXEN | Ingénierie & Performance Énergétique';
    let metaDesc = 'Réduisez la facture énergétique de vos sites industriels, tertiaires et résidentiels collectifs : audit, travaux, financement CEE et suivi des économies. Partout en France.';

    if (currentPath === '/') {
      title = 'PEXEN | Ingénierie & performance énergétique';
    } else if (currentPath === '/expertises/') {
      title = 'Nos expertises en performance énergétique | PEXEN';
    } else if (currentPath.startsWith('/expertises/froid')) {
      title = 'Froid commercial et industriel | PEXEN';
    } else if (currentPath.startsWith('/expertises/recuperation-de-chaleur')) {
      title = 'Récupération de chaleur | PEXEN';
    } else if (currentPath.startsWith('/expertises/chauffage-traitement-air')) {
      title = 'Pompes à chaleur et déstratification | PEXEN';
    } else if (currentPath.startsWith('/expertises/gtb-gtc')) {
      title = 'GTB / GTC et décret BACS | PEXEN';
    } else if (currentPath.startsWith('/expertises/isolation-technique')) {
      title = 'Isolation technique | PEXEN';
    } else if (currentPath.startsWith('/expertises/reglementation-cee')) {
      title = 'Décret tertiaire, décret BACS et financement CEE | PEXEN';
    } else if (currentPath === '/secteurs/') {
      title = 'Industrie, tertiaire, résidentiel collectif | PEXEN';
    } else if (currentPath.startsWith('/secteurs/industrie')) {
      title = 'Performance énergétique industrielle | PEXEN';
    } else if (currentPath.startsWith('/secteurs/tertiaire')) {
      title = 'Performance énergétique tertiaire | PEXEN';
    } else if (currentPath.startsWith('/secteurs/residentiel-collectif')) {
      title = 'Performance énergétique du résidentiel collectif | PEXEN';
    } else if (currentPath.startsWith('/realisations')) {
      title = 'Nos réalisations en performance énergétique | PEXEN';
    } else if (currentPath === '/notre-approche/') {
      title = 'Notre approche : conseil, ingénierie, suivi | PEXEN';
    } else if (currentPath === '/contact/') {
      title = 'Contact : parlez de votre projet | PEXEN';
    } else if (currentPath === '/contact/merci/') {
      title = 'Merci pour votre demande | PEXEN';
    } else if (currentPath === '/mentions-legales/') {
      title = 'Mentions légales | PEXEN';
    } else if (currentPath === '/politique-de-confidentialite/') {
      title = 'Politique de confidentialité | PEXEN';
    } else if (currentPath === '/cookies/') {
      title = 'Gestion des cookies | PEXEN';
    }

    document.title = title;
    const metaTag = document.querySelector('meta[name="description"]');
    if (metaTag) {
      metaTag.setAttribute('content', metaDesc);
    }
  }, [currentPath]);

  const navigate = (newPath: string) => {
    let cleanPath = newPath.endsWith('/') ? newPath : `${newPath}/`;
    
    // Check D1 301 redirects
    if (REDIRECTS_MAP[cleanPath] || REDIRECTS_MAP[newPath]) {
      cleanPath = REDIRECTS_MAP[cleanPath] || REDIRECTS_MAP[newPath];
    }

    try {
      window.history.pushState({}, '', cleanPath);
    } catch (e) {
      // In sandbox if pushState restricted
    }
    setCurrentPath(cleanPath);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Route resolver
  const renderCurrentView = () => {
    // 1. Home
    if (currentPath === '/' || currentPath === '') {
      return (
        <HomeView
          onNavigate={navigate}
          onOpenProjectModal={(slug) => setSelectedModalSlug(slug)}
        />
      );
    }

    // 2. Expertises general or sub-routes
    if (currentPath.startsWith('/expertises/')) {
      const parts = currentPath.split('/').filter(Boolean);
      const subSlug = parts[1]; // e.g., 'froid', 'recuperation-de-chaleur', 'reglementation-cee'
      return (
        <ExpertisesView
          currentSubSlug={subSlug}
          onNavigate={navigate}
          onOpenProjectModal={(slug) => setSelectedModalSlug(slug)}
        />
      );
    }

    // 3. Secteurs general or sub-routes
    if (currentPath.startsWith('/secteurs/')) {
      const parts = currentPath.split('/').filter(Boolean);
      const subSlug = parts[1]; // e.g., 'industrie', 'tertiaire', 'residentiel-collectif'
      return (
        <SecteursView
          currentSubSlug={subSlug}
          onNavigate={navigate}
          onOpenProjectModal={(slug) => setSelectedModalSlug(slug)}
        />
      );
    }

    // 4. Realisations
    if (currentPath.startsWith('/realisations/')) {
      const parts = currentPath.split('/').filter(Boolean);
      const projectSlug = parts[1];
      return (
        <RealisationsView
          currentSlug={projectSlug}
          onNavigate={navigate}
          selectedModalSlug={selectedModalSlug}
          onCloseModal={() => setSelectedModalSlug(null)}
        />
      );
    }

    // 5. Notre approche
    if (currentPath === '/notre-approche/') {
      return <NotreApprocheView onNavigate={navigate} />;
    }

    // 6. Contact & Merci
    if (currentPath === '/contact/') {
      return (
        <ContactView
          onNavigate={navigate}
          onSubmitSuccess={() => navigate('/contact/merci/')}
        />
      );
    }
    if (currentPath === '/contact/merci/') {
      return <MerciView onNavigate={navigate} />;
    }

    // 7. Legals
    if (currentPath === '/mentions-legales/') {
      return (
        <LegalView
          type="mentions-legales"
          onNavigate={navigate}
          onOpenCookies={() => setCookieBannerOpen(true)}
        />
      );
    }
    if (currentPath === '/politique-de-confidentialite/') {
      return (
        <LegalView
          type="politique-de-confidentialite"
          onNavigate={navigate}
          onOpenCookies={() => setCookieBannerOpen(true)}
        />
      );
    }
    if (currentPath === '/cookies/') {
      return (
        <LegalView
          type="cookies"
          onNavigate={navigate}
          onOpenCookies={() => setCookieBannerOpen(true)}
        />
      );
    }

    // 8. 404
    return <NotFoundView onNavigate={navigate} />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F7FA] text-[#0B1528] selection:bg-[#00C6BA]/20 selection:text-[#0B1528]">
      {/* Persistent sticky navigation header */}
      <Header currentPath={currentPath} onNavigate={navigate} />

      {/* Main page content */}
      <main className="flex-1">
        {renderCurrentView()}
      </main>

      {/* Deep Navy Footer */}
      <Footer
        onNavigate={navigate}
        onOpenCookies={() => setCookieBannerOpen(true)}
      />

      {/* Cookie Consent Banner */}
      <CookieBanner
        isOpen={cookieBannerOpen}
        onClose={() => setCookieBannerOpen(false)}
        onNavigateToCookies={() => {
          setCookieBannerOpen(false);
          navigate('/cookies/');
        }}
      />

      {/* Floating AI Assistant Button (Bottom Left) */}
      <AiAssistantButton onNavigateToContact={() => navigate('/contact/')} />

      {/* Floating WhatsApp Button (Bottom Right) */}
      <WhatsAppButton />
    </div>
  );
}
